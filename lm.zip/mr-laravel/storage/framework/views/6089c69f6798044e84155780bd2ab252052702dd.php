<!doctype>
<title>web sit</title>
<link rel="stylesheet" href="/app.css" >
<body>
<article>
 <?= $post ?>
</article>
<a href="/" >go back</a>
<?php /**PATH C:\xampp\htdocs\liba\example-app\resources\views/post.blade.php ENDPATH**/ ?>